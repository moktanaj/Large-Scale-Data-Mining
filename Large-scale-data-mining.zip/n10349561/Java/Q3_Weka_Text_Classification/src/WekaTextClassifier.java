import java.util.Random;

import weka.classifiers.AbstractClassifier;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.SMO;
import weka.classifiers.lazy.IBk;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.trees.HoeffdingTree;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.core.SelectedTag;
import weka.core.converters.ConverterUtils.DataSource;
import weka.core.stemmers.LovinsStemmer;
import weka.core.stopwords.Rainbow;
import weka.core.tokenizers.AlphabeticTokenizer;
import weka.filters.unsupervised.attribute.StringToWordVector;

public class WekaTextClassifier {
	
	public void doAllFilteredClassification()
	{
		try { 
			System.out.println("data.....");
			DataSource source = new DataSource("/Users/ajaymoktan/Desktop/AI&LSDM/LSDM-IFN645/PRAC/LSDM-Assign-2/Q1.1/News.arff");
			Instances data = source.getDataSet();
			// calling classification function to perform classification
			
			// J48 
//			long startJ48 = System.nanoTime();
//			doClassification(new J48(), data, "J48");
//			long endJ48 = System.nanoTime();
//			double elapsedJ48 = endJ48 - startJ48;
//			elapsedJ48 = elapsedJ48/ 1000000000;
//			System.out.println("Executing J48: " + elapsedJ48 + " seconds\n");
//			
//			//IBK
//			long startIBK = System.nanoTime();
//			doClassification(new IBk(), data, "IBK");
//			long endIBK = System.nanoTime();
//			double elapsedIBK = endIBK - startIBK;
//			elapsedIBK = elapsedIBK/ 1000000000;
//			System.out.println("Executing IBK: " + elapsedIBK + " seconds\n");
//			
//			//SMO
//			long startSMO = System.nanoTime();
//			doClassification(new SMO(), data, "SMO");
//			long endSMO = System.nanoTime();
//			double elapsedSMO = endSMO - startSMO;
//			elapsedSMO = elapsedSMO/ 1000000000;
//			System.out.println("Executing SMO: " + elapsedSMO + " seconds\n");
			
//			//HoeffdingTree
//			long startHT = System.nanoTime();
//			doClassification(new HoeffdingTree(), data, "HoeffdingTree");
//			long endHT= System.nanoTime();
//			double elapsedHT = endHT - startHT;
//			elapsedHT = elapsedHT/ 1000000000;
//			System.out.println("Executing HoeffdingTree: " + elapsedHT + " seconds\n");
			
			//HoeffdingTree
			long start = System.nanoTime();
			doClassification(new HoeffdingTree(), data, "HoeffdingTree");
			calculateTime(start,"HoeffdingTree");
			
			//SMO
			start = System.nanoTime();
			doClassification(new SMO(), data, "SMO");
			calculateTime(start,"SMO");
			
			 }
	         catch(Exception e){
	       	  System.out.println("Error in ...");
	       	  System.out.println(e.getMessage());
	       	  e.printStackTrace();
        }
	}
	
	public void calculateTime(long start, String Name) {
		
		long end= System.nanoTime();
		double elapsed = end - start;
		elapsed = elapsed/ 1000000000;
		System.out.println("Executing "+ Name +"in " + elapsed + " seconds\n");
		
	}
	// Classification and Evaluation
	
	public void doClassification(AbstractClassifier classifier, Instances data, String Name)throws Exception {
		
		try {  
			//Setting the class index of the dataset 
			data.setClassIndex(1);
			
			// Create a StringToWordVector filter 
			StringToWordVector swFilter = new StringToWordVector();
			
			// Range of attributes specified by StringToWordVector. 
			// We want to work on the entire list of words
			swFilter.setAttributeIndices("first-last"); 
			
			// Filter Configuration
			swFilter.setIDFTransform(true);
			swFilter.setTFTransform(true);
			swFilter.setNormalizeDocLength(
		            new SelectedTag(StringToWordVector.FILTER_NORMALIZE_ALL, StringToWordVector.TAGS_FILTER));
			swFilter.setOutputWordCounts(true);
			swFilter.setStemmer(new LovinsStemmer());
			swFilter.setStopwordsHandler(new Rainbow());
			swFilter.setTokenizer(new AlphabeticTokenizer());
			swFilter.setWordsToKeep(100);
			
			// Create a FilteredClassifier object
			FilteredClassifier filter_classifier = new FilteredClassifier();
			
			// Set the filter to the filtered classifier
			filter_classifier.setFilter(swFilter);
			filter_classifier.setClassifier(classifier);
			filter_classifier.buildClassifier(data);
			
			// Evaluation
			System.out.println(Name + " Evaluation in progress....");
			Evaluation eval = new Evaluation(data);
			eval.crossValidateModel(filter_classifier, data, 10, new Random(1));
			System.out.println("Done \n");
			System.out.println(eval.toSummaryString());
			System.out.println("Accuracy = "+eval.pctCorrect());
			System.out.println(Name + " Evaluating on filtered (training) dataset done.");
			 }
	         catch(Exception e){
	       	  System.out.println("Error in ...");
	       	  System.out.println(e.getMessage());
	       	  e.printStackTrace();
        }
		
	}
	

	public static void main(String[] args) throws Exception {
		
		WekaTextClassifier tc =new WekaTextClassifier();
		tc.doAllFilteredClassification();	

	}

}
