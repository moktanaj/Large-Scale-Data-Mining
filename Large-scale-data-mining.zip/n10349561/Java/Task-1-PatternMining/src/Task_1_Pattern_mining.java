import java.io.IOException;

import ca.pfv.spmf.algorithms.associationrules.TopKRules_and_TNR.AlgoTopKClassRules;
import ca.pfv.spmf.algorithms.associationrules.TopKRules_and_TNR.Database;
import ca.pfv.spmf.algorithms.frequentpatterns.apriori.AlgoApriori;
import ca.pfv.spmf.algorithms.frequentpatterns.apriori_close.AlgoAprioriClose;
import ca.pfv.spmf.algorithms.frequentpatterns.charm.AlgoCharm_Bitset;
import ca.pfv.spmf.algorithms.frequentpatterns.fpgrowth.AlgoFPClose;
import ca.pfv.spmf.algorithms.frequentpatterns.fpgrowth.AlgoFPGrowth;
import ca.pfv.spmf.algorithms.frequentpatterns.fpgrowth.AlgoFPMax;
import ca.pfv.spmf.input.transaction_database_list_integers.TransactionDatabase;
import ca.pfv.spmf.tools.dataset_converter.TransactionDatabaseConverter;
import ca.pfv.spmf.tools.resultConverter.ResultConverter;
public class Task_1_Pattern_mining {
	
	//**** Q1.1 METHODS TO GENERATE MOST FREQUENT PATTERNS *****
	
		// 1.1.1 Using Apriori Algorithm for FP
		public void doApriori(String input_file, String output_path, double minsup) {
				
			//Generating output file name dynamically
			//output_file = output_path + name suffixed with minsup
			String output_file = output_path + "output_fp_Apriori_"+minsup+".txt";
				
			System.out.println("Mininum Support = "+ minsup);
			try {
					
				// Create object of pattern Apriori algorithms
				AlgoApriori algo_Apri = new AlgoApriori();
				algo_Apri.runAlgorithm(minsup, input_file, output_file );
				algo_Apri.printStats();
					
			}catch (IOException e) {
				e.printStackTrace();
			}	
				
		}
			
		// 1.1.2 Using FP Growth Algorithm for FP
		public void doFPGrowth(String input_file, String output_path, double minsup) {
				
			//Generating output file name dynamically
			// output_file = output_path + name suffixed with minsup 
			String output_file = output_path + "output_fp_FPGrowth_"+minsup+".txt";
				
			// Create object of pattern Apriori algorithms
				
			System.out.println("Mininum Support = "+ minsup);
			try {
					
				AlgoFPGrowth algo_FPGrowth = new AlgoFPGrowth();
				algo_FPGrowth.runAlgorithm(input_file, output_file, minsup);
				algo_FPGrowth.printStats();
					
			}catch (IOException e) {
				e.printStackTrace();
			}	
				
		}
		
		
		//**** Q1.2 METHODS TO GENERATE TOP 5 MOST FREQUENT PATTERNS*****
		
		// 1.2.1 Method to generate  top 5 most frequent patterns from bank_yes.txt file
		public void doBank_yes(String input_txt_bank_yes, String output_path, double minsup) {
			
			// output_file = output_path + name + suffixed with minsup 
			String output_file = output_path + "output_bank_yes.txt";
			String final_output_file = output_path + "final_output_bank_yes.txt";
							
			// Create object of FP Growth class
								
			try {
				AlgoFPGrowth algo_FPGrowth = new AlgoFPGrowth();
				algo_FPGrowth.setMinimumPatternLength(3);
				algo_FPGrowth.setMaximumPatternLength(3);
				algo_FPGrowth.runAlgorithm(input_txt_bank_yes, output_file, minsup);
				algo_FPGrowth.printStats();
				//converting the output to include the name of item
				convert_output(input_txt_bank_yes, output_file, final_output_file);
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
		}	
		
		// 1.2.2 Method to generate  top 5 most frequent patterns from bank_no.txt file
		public void doBank_no(String input_txt_bank_no, String output_path, double minsup) {
			
			// output_file = output_path + name + suffixed with minsup 
			String output_file = output_path + "output_bank_no.txt";
			String final_output_file = output_path + "final_output_bank_no.txt";
			
							
			// Create object of FP Growth class
			try {									
				AlgoFPGrowth algo_FPGrowth = new AlgoFPGrowth();
				algo_FPGrowth.setMinimumPatternLength(3);
				algo_FPGrowth.setMaximumPatternLength(3);
				algo_FPGrowth.runAlgorithm(input_txt_bank_no, output_file, minsup);
				algo_FPGrowth.printStats();	
				//converting the output to include the name of item
				convert_output(input_txt_bank_no, output_file, final_output_file);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
				
		}
		//********** Q1.3 GENERATEING TOP 5 MAXIMAL FREQUENT PATTERNS******
		
		// 1.3.1 Method to generate top 5 maximal frequent patterns from bank_yes.txt file
		public void doMaxFp_yes(String input_dataset, String output_path, double minsup) {
			
			//specifying output file 
			String output_yes = output_path + "output_MaxFp_yes";
			String final_output_yes = output_path + "final_output_MaxFp_yes";
			
			try {
				//creating an object of AlgoFPMax
				AlgoFPMax algo_FPMax = new AlgoFPMax();
				algo_FPMax.runAlgorithm(input_dataset, output_yes, minsup);
				algo_FPMax.printStats();
				//Convert outputs to include item names
				convert_output(input_dataset, output_yes, final_output_yes);
			}catch (IOException e) {
				e.printStackTrace();
			}
		}
		// 1.3.2 Method to generate top 5 maximal frequent patterns from bank_no.txt file
		
		public void doMaxFp_no(String input_dataset, String output_path, double minsup) {
			
			//specifying output file 
			String output_no = output_path + "output_MaxFp_no";
			String final_output_no = output_path + "final_output_MaxFp_no";
			
			try {
				//creating an object of AlgoFPMax
				AlgoFPMax algo_FPMax = new AlgoFPMax();
				algo_FPMax.runAlgorithm(input_dataset, output_no, minsup);
				algo_FPMax.printStats();
				//Convert outputs to include item names
				convert_output(input_dataset, output_no, final_output_no);
			}catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		//****** Q1.4 METHODS TO GENERATE FREQUENT CLOSED PATTERNS *********
		
		// 1.4.1 Using Apriori Close algorithm
		public void doFCP_AprioriClose(String input_dataset, String output_path, double minsup) {
			String output = output_path + "fcp_Apriori.txt";
			String final_output = output_path + "final_fcp_Apriori.txt";
			
			try {
				AlgoAprioriClose algo_AprioriClose = new AlgoAprioriClose();
				
				algo_AprioriClose.runAlgorithm(minsup, input_dataset, output);
				algo_AprioriClose.printStats();
				
				//Convert outputs to include item names
				convert_output(input_dataset, output, final_output);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		// 1.4.2 Using FPClose algorithm
		public void doFCP_Growth(String input_dataset, String output_path, double minsup) {
			String output = output_path + "fcp_Fpt.txt";
			String final_output = output_path + "final_fcp_Fpt.txt";
			
			try {
				AlgoFPClose algo_FCP_Growth = new AlgoFPClose(); 
				algo_FCP_Growth.runAlgorithm(input_dataset, output, minsup);
				algo_FCP_Growth.printStats();
				
				//Convert outputs to include item names
				convert_output(input_dataset, output, final_output);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		// 1.4.3 Using Charm Algorithm
		public void doFCP_Charm(String input_dataset, String output_path, double minsup) {
			String output = output_path + "fcp_Charm.txt";
			String final_output = output_path + "final_fcp_Charm.txt";
			
			try {
				AlgoCharm_Bitset algo_FCP_Charm = new AlgoCharm_Bitset();
				
				//AlgoCharm_Bitset requires transaction database 
				TransactionDatabase tdb = new TransactionDatabase(); 
				tdb.loadFile(input_dataset);
				
				algo_FCP_Charm.runAlgorithm(output, tdb, minsup, false, 10000);
				algo_FCP_Charm.printStats();
				
				convert_output(input_dataset, output, final_output);
				
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}
		
		//***** Q1.5 GENERATING TOP 10 MOST FREQUENT ASSOCIATION RULES ********************
		
		public void topK_classRules(String input_dataset, String output_path, double minconf, int top_k, int[] itemToBeUsedAsConsequent) {
			// Output file variables
			String output;
			String final_output;
			// Specifying output files for subscribed=yes and subscribed=no
			if (itemToBeUsedAsConsequent[0] == 42) {
				System.out.println("Top-K, Subscribed = yes");
				output = output_path + "topK_classRules_yes.txt" ;
				final_output = output_path + "final_topK_classRules_yes.txt" ;
				
			}else {
				System.out.println("Top-K, Subscribed = no");
				output = output_path + "topK_classRules_no.txt" ;
				final_output = output_path + "final_topK_classRules_no.txt" ;
				
			}
			
			
			// To generate rules, we need to create a database from the input dataset
			Database db = new Database(); 
			try {
				db.loadFile(input_dataset);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
			// Create an object of rule mining algorithm
			AlgoTopKClassRules topK_classRules = new AlgoTopKClassRules(); 
			
			// Generate association rules 
			topK_classRules.runAlgorithm(top_k, minconf, db, itemToBeUsedAsConsequent);
			topK_classRules.printStats();
			try {
				topK_classRules.writeResultTofile(output);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			//Convert outputs to include the original names for the items
			ResultConverter output_converter = new ResultConverter();
			try {
				output_converter.convert(input_dataset, output, final_output, null);
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}
		
		
		// ***** METHOD TO CONVERT OUTPUT FILE TO CONTAIN ITEM NAME *****
		
		public void convert_output(String input_dataset, String output, String final_output) {
			try {
				//Convert outputs to include item names
				ResultConverter output_converter = new ResultConverter();
				output_converter.convert(input_dataset, output, final_output, null);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	//**************************** THE MAIN METHOD *****************************//
	//**************************************************************************//
		
	public static void main(String[] args) throws IOException {
		
		//Specify original (.arff) input file
		String input_arff_bank = "/Users/ajaymoktan/Desktop/AI&LSDM/LSDM-IFN645/Assign-2/datasets/bank.arff";
		String input_arff_yes = "/Users/ajaymoktan/Desktop/AI&LSDM/LSDM-IFN645/Assign-2/datasets/bank_yes.arff";
		String input_arff_no = "/Users/ajaymoktan/Desktop/AI&LSDM/LSDM-IFN645/Assign-2/datasets/bank_no.arff";
						
		// Specify a converted text file name and location
		String input_txt_file_bank  =  "/Users/ajaymoktan/Desktop/AI&LSDM/LSDM-IFN645/PRAC/LSDM-Assign-2/IO-Files/bank.txt";
		String input_txt_bank_yes  =  "/Users/ajaymoktan/Desktop/AI&LSDM/LSDM-IFN645/PRAC/LSDM-Assign-2/IO-Files/bank_yes.txt";
		String input_txt_bank_no  =  "/Users/ajaymoktan/Desktop/AI&LSDM/LSDM-IFN645/PRAC/LSDM-Assign-2/IO-Files/bank_no.txt";
						
		//Create an object of TransactionDatabaseConverter
		TransactionDatabaseConverter converter = new TransactionDatabaseConverter();
						 
		// Convert the ARFF file to text file
		converter.convertARFFandReturnMap(input_arff_yes, input_txt_bank_yes, Integer.MAX_VALUE);
		converter.convertARFFandReturnMap(input_arff_no, input_txt_bank_no, Integer.MAX_VALUE);
		converter.convertARFFandReturnMap(input_arff_bank, input_txt_file_bank, Integer.MAX_VALUE);
						
		// Output file path for most frequent pattern
				
		String output_path_FP = "/Users/ajaymoktan/Desktop/AI&LSDM/LSDM-IFN645/PRAC/LSDM-Assign-2/IO-Files/output_Q1_1/";
				
		// Output file path for Top 5 frequent pattern
		String output_path_T5FP = "/Users/ajaymoktan/Desktop/AI&LSDM/LSDM-IFN645/PRAC/LSDM-Assign-2/IO-Files/output_Q1_2/";
				
		// Output file path for Top 5 maximal pattern
		String output_path_MaxFp = "/Users/ajaymoktan/Desktop/AI&LSDM/LSDM-IFN645/PRAC/LSDM-Assign-2/IO-Files/output_Q1_3/";
				
		// Output file path for Top 5 maximal pattern
		String output_path_fcp = "/Users/ajaymoktan/Desktop/AI&LSDM/LSDM-IFN645/PRAC/LSDM-Assign-2/IO-Files/output_Q1_4/";
				
		// Output file path for Top 10 Association Rules for specified consequents.
		String output_path_TopK = "/Users/ajaymoktan/Desktop/AI&LSDM/LSDM-IFN645/PRAC/LSDM-Assign-2/IO-Files/output_Q1_5/";
				
		// Specifying the 3 different minimum support as an array for Most frequent pattern.
		double[] MinSups = {0.2, 0.4, 0.6};
						
		// minimum support for yes and no dataset for Top 5 frequent pattern
		double minsup_yes = 0.43; 
		double minsup_no = 0.48; 
				
		// minimum support for yes and no dataset for Top 5 maximal pattern.
		double minsup_MaxFp_yes = 0.5;
		double minsup_MaxFp_no = 0.53;
				
		// minimum support to find frequent closed pattern
		double minsup_closed = 0.4;
				
		//minimum Confidence to generate top 10 association rules
		double minconf = 0.3;
		// Top K 
		int top_k = 10;
		// The items to be used as a consequents for generating association rules
		// where 11 = no subscribed and 42 = yes subscribed.
		int[] itemToBeUsedAsConsequent_yes = new int[] {42};
		int[] itemToBeUsedAsConsequent_no = new int[] {11};
				
				
		// Creating the object of main class Top5_Size3_FPG
		Task_1_Pattern_mining FPM = new Task_1_Pattern_mining();
				
		// Q1.1 extracting each minimum support as minsup and looping 3 times
		for (double minsup : MinSups) {
							
			FPM.doApriori(input_txt_file_bank, output_path_FP, minsup);
			FPM.doFPGrowth(input_txt_file_bank, output_path_FP, minsup);	
			}
							
				
		// calling the methods inside the main class Top5_Size3_FPG
		// Q1.2
		FPM.doBank_yes(input_txt_bank_yes, output_path_T5FP, minsup_yes);
		FPM.doBank_no(input_txt_bank_no, output_path_T5FP, minsup_no);
				
		// Q1.3 calling doMaxFp_yes and doMaxFp_no to generate top 5 maximal pattern.
		FPM.doMaxFp_yes(input_txt_bank_yes, output_path_MaxFp, minsup_MaxFp_yes);
		FPM.doMaxFp_no(input_txt_bank_no, output_path_MaxFp, minsup_MaxFp_no);
				
		// Q1.4 
		// Generating frequent Closed patterns for fcp_Apriori
		FPM.doFCP_AprioriClose(input_txt_file_bank, output_path_fcp, minsup_closed);
				
		// Generating frequent closed pattern using FPClose algorithm
		FPM.doFCP_Growth(input_txt_file_bank, output_path_fcp, minsup_closed);
				
		// Generating frequent closed patterns using Charm algorithm
		FPM.doFCP_Charm(input_txt_file_bank, output_path_fcp, minsup_closed);
				
		// Q1.5 
		// Generating Top 10 most frequent association rules for subscribed=yes as a consequent
		FPM.topK_classRules(input_txt_file_bank, output_path_TopK, minconf, top_k, itemToBeUsedAsConsequent_yes);
		// Generating Top 10 most frequent association rules for subscribed=no as a consequent
		FPM.topK_classRules(input_txt_file_bank, output_path_TopK, minconf, top_k, itemToBeUsedAsConsequent_no);
					
		}
		
}


